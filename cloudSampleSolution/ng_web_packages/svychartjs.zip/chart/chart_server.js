$scope.api.setOptions = function(options) {
	$scope.model.options = options;
}

$scope.api.setData = function(data) {
	$scope.model.data = data;
}

$scope.api.setPlugin = function(plugin) {
	$scope.model.plugin = plugin;
}